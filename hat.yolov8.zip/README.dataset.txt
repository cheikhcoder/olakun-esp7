# DOUANE_DETECTION > 2024-05-04 2:32pm
https://universe.roboflow.com/detection-biu71/douane_detection

Provided by a Roboflow user
License: CC BY 4.0

